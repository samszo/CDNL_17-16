
<?php 


$separateurs = ",.;\'() ";

// lecture d'une source texte 
$chaine = implode( file('source.txt'),' ');
$chaine = strtolower($chaine);


// decoupage de la chaine en elements mots 
$tab_mots = explode_bise($separateurs, $chaine); 
print_array($tab_mots);

//filtrage de doublons et obtebtion de nombre d'occurrences
$tab_mots_soccurrences = array_count_values($tab_mots);
print_array($tab_mots_soccurrences);

        function explode_bise($separateurs, $chaine)
        {
                $tab = array();
                $tok= strtok($chaine, $separateurs);
                    if (strlen($tok) > 2) $tab[] = $tok;
                    //echo  $tok, "<br>";
                
                    while ( $tok !== false )
                        {
                            
                            $tok = strtok($separateurs);
                            if (strlen($tok) > 2) $tab[] = $tok;
                            //echo  $tok, "<br>";
                        }
                    return $tab;
        }
        
        function print_array($Token){
            
            
            foreach ( $Token as $cle => $valeur)
                
                echo "[ $cle ]=",$valeur,"<br>";
        }
?>