<?php

$Str = "Bonjour tout le monde";

$Token = explode(' ',$Str);

print_array($Token);

function print_array($Token){
    
    
    foreach ( $Token as $cle => $valeur)
        
        echo "[ $cle ]=",$valeur,"<br>";
}



?>